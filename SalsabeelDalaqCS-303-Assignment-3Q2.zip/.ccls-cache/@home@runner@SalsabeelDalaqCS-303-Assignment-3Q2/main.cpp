#include <iostream>
using namespace std;

const int MAX_SIZE = 100;   // Maximum size of the queue

class Queue {
    private:
        int arr[MAX_SIZE];  // Array to store elements of the queue
        int front;          // Index of front element
        int rear;           // Index of rear element
        int size;           // Current size of the queue

    public:
        Queue() {
            front = rear = -1;  // Initialize front and rear indices to -1
            size = 0;           // Initialize current size to 0
        }

        // Inserts a new element at the rear
        void enqueue(int element) {
            if (size == MAX_SIZE) {
                cout << "Queue is full. Cannot insert more elements." << endl;
                return;
            }

            if (front == -1) {
                front++;
            }

            rear++;
            arr[rear] = element;
            size++;
        }

        // Removes the front element of the queue and returns it.
        int dequeue() {
            if (front == -1 || front > rear) {
                cout << "Queue is empty. Cannot dequeue elements." << endl;
                return -1;
            }

            int element = arr[front];
            front++;
            size--;

            return element;
        }

        // Returns the front element present in the queue without removing it.
        int peek() {
            if (front == -1 || front > rear) {
                cout << "Queue is empty. Cannot peek elements." << endl;
                return -1;
            }

            return arr[front];
        }

        // Checks if the queue is empty
        bool isEmpty() {
            return (front == -1 || front > rear);
        }

        // Returns the total number of elements present in the queue
        int getSize() {
            return size;
        }
};

int main() {
    Queue q;

    q.enqueue(1);           // Insert element 1 at rear
    q.enqueue(2);           // Insert element 2 at rear
    q.enqueue(3);           // Insert element 3 at rear
    cout << "Size of queue: " << q.getSize() << endl;      // Output: 3

    cout << "Front element: " << q.peek() << endl;         // Output: 1
    cout << "Removed element: " << q.dequeue() << endl;    // Output: 1

    cout << "Size of queue: " << q.getSize() << endl;      // Output: 2

    q.enqueue(4);           // Insert element 4 at rear
    cout << "Front element: " << q.peek() << endl;         // Output: 2

    cout << "Is queue empty? " << (q.isEmpty() ? "Yes" : "No") << endl; // Output: No

    return 0;
}